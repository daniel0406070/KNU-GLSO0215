NHYOK CHOI

![face.jpg](face.jpg)

### Contact

---

**Address**
Daegu, KR

**Phone**
+82-10-9509-9358

**E-mail**
daniel0406070@gmail.com

### Websites

---

- linkedin.com/in/daniel0406070
- github.com/daniel0406070
- instagram.com/daniel040607

### Skills

---

Project management
● ● ● ● ●

Business planning
● ● ● ○ ○

Data analysis
● ● ● ○ ○

Software development
● ● ● ● ●

Software architecture
● ● ● ● ●

System architecture
● ● ● ● ○

Proficiency in C, C#
● ● ● ● ●

### Langues

---

🇰🇷 Korean (Native)
● ● ● ● ●

🇺🇸 English
● ● ● ● ○

🇷🇺 Russian
● ● ○ ○ ○

## University Student

Thorough team contributor with strong organizational capabilities. Experienced in handling numerous projects at once while ensuring accuracy. Effective at prioritizing tasks and meeting deadlines.
Equipped with strong problem-solving abilities, willingness to learn, and excellent communication skills. Poised to contribute to team success and achieve positive results. Ready to tackle new challenges and advance organizational objectives with dedication and enthusiasm.

### Expecting from SWMaestro Global  program

---

By participating in the SW Maestro Global Program, I expect to gain abundant knowledge and experience and greatly improve my skills and my view of the world through this. I want to hear various experiences and get potential collaboration opportunities through experts and mentors.  I want to get insights to get ahead in the rapidly evolving technology environment through global trends and technology best practices. I want to find innovative improvements to our ideas in an innovative and creative environment.

### **Work history**

---

### **2024-
Current**

### **CTO(Chief Technical Officer)**
EasterAd, Seoul, South Korea

- Designed enterprise-level technological blueprints and system architectures.
- Implemented agile methodologies for software development, increasing speed-to-market without sacrificing quality or security standards.
- Maintained thorough understanding of all key and current technologies, platforms and trends.

### **Education**

---

### Expected
in 2027-08

### Bachelor of Science in Advanced Computing: Platform SW & Data Science

Kyungpook National University - Daegu, South Korea

### **Certifications**

---

### 2024-12

### 2023-9

### 2023-7

### SWMaestro Excellence Certification

### ADVANCED ADVENTURE DIVER

### OPEN WATER SCUBA DIVER
